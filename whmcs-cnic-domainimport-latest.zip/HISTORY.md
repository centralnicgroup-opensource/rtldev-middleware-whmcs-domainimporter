## [1.0.2](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.0.1...v1.0.2) (2021-08-03)


### Bug Fixes

* **module label:** updated ([3718f8d](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/3718f8d4e16e641472842350a2594ddad27d4488))

## [1.0.1](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.0.0...v1.0.1) (2021-08-03)


### Bug Fixes

* **gulp:** fixed archive file name ([4e8f62b](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/4e8f62b65db1a9e157aa14e461f7fb6c10a0ce3f))

# 1.0.0 (2021-08-03)


### Features

* **initial version:** revamped solution deprecating the matching ispapi addon variant ([3a91fd4](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/3a91fd4aa07631485c2662365cc224c0430f79ee))
