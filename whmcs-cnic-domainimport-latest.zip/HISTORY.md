# [1.3.0](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.2.3...v1.3.0) (2021-08-12)


### Features

* **idnlanguage:** import idnLanguage if provided ([9f2ed01](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/9f2ed01817687aefcc5ec73eb3cce7a5438185b5))

## [1.2.3](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.2.2...v1.2.3) (2021-08-05)


### Bug Fixes

* **fn check:** remove deprecated function check ([e208f32](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/e208f32c6da8b4b71a3bbc0789d0643baa13b46a))

## [1.2.2](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.2.1...v1.2.2) (2021-08-04)


### Bug Fixes

* **welcome email:** fixed bug in subscription while creating customers ([39624a6](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/39624a6961db956a575a8af5733379c29c53bfd2))

## [1.2.1](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.2.0...v1.2.1) (2021-08-04)


### Bug Fixes

* **add client:** fixed issues with adding clients ([0bad63a](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/0bad63aef9ecfc0a5e6c2c173d126b9b8d50a540))

# [1.2.0](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.1.0...v1.2.0) (2021-08-03)


### Features

* **premium domains:** display them with a star ([cac9ac4](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/cac9ac42b12000fd1d69f84c00054a9914cafcac))

# [1.1.0](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.0.2...v1.1.0) (2021-08-03)


### Features

* **local presence service:** display imported domains with active local presence service ([e5a9fc7](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/e5a9fc75d07b2efac7bbe705bb19a0b49d0c84a5))

## [1.0.2](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.0.1...v1.0.2) (2021-08-03)


### Bug Fixes

* **module label:** updated ([3718f8d](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/3718f8d4e16e641472842350a2594ddad27d4488))

## [1.0.1](https://github.com/centralnic-reseller/whmcs-domainimporter/compare/v1.0.0...v1.0.1) (2021-08-03)


### Bug Fixes

* **gulp:** fixed archive file name ([4e8f62b](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/4e8f62b65db1a9e157aa14e461f7fb6c10a0ce3f))

# 1.0.0 (2021-08-03)


### Features

* **initial version:** revamped solution deprecating the matching ispapi addon variant ([3a91fd4](https://github.com/centralnic-reseller/whmcs-domainimporter/commit/3a91fd4aa07631485c2662365cc224c0430f79ee))
